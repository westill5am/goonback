git add build.sh
git commit -m "Add build.sh for Puppeteer dependencies"
git push
